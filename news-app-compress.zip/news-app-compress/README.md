# To get the app running,

--> command 1; npm install

--> command 2: npm start 
