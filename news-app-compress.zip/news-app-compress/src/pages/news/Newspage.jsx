import React from 'react'
import './News.css'
const Newspage = () => {
  return (
    <div>news</div>
  )
}

export default Newspage
