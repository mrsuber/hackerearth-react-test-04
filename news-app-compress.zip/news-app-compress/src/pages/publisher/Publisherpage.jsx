import React from 'react'
import './Publisherpage'
const Publisherpage = () => {
  return (
    <div>publisher</div>
  )
}

export default Publisherpage
