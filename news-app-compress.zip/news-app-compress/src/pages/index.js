export {default as Homepage} from './home/Homepage'
export { default as News} from './news/Newspage'
export {default as Publisherpage} from './publisher/Publisherpage'
export {default as Rootpage} from './root/Rootpage'
